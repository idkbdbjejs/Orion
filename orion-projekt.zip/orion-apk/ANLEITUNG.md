# ORION — Anleitung

## Das war dein Fehler

Auf deinen Bildern steht in der Adresszeile `content://downloads/all_download`. Du hast die Datei **direkt aus dem Download-Ordner geöffnet**. Android sperrt dort Mikrofon, Kamera und Bildschirmfreigabe komplett — daher kam bei jedem Versuch `NotAllowedError`. Das lässt sich nicht per Einstellung freischalten.

Der zweite Fehler: **das Modell `gemini-2.5-flash` gibt es für neue Schlüssel nicht mehr.** Deshalb blieb sogar ein getipptes „Hallo" ohne Antwort. Es steht jetzt kein fester Modellname mehr im Code — ORION fragt deinen Schlüssel, welche Modelle er benutzen darf, und nimmt automatisch das neueste.

Der dritte: Bei dir stand die Sprachausgabe auf „OpenAI", mit einem Google-Schlüssel. Das kann nur scheitern. Wird beim Start jetzt selbst korrigiert.

---

## Weg 0 — die schnellste Lösung (empfohlen)

Damit bekommst du in fünf Minuten eine echte HTTPS-Adresse, ohne irgendetwas zu installieren:

1. Bei [github.com](https://github.com) ein neues Repository anlegen, Name `orion`, **Public**
2. **Add file → Upload files** → alle Dateien und Ordner aus dem Paket hochladen (auch `.github`)
3. Repo → **Settings → Pages** → unter *Source* **GitHub Actions** wählen
4. Reiter **Actions** → **0 – Sofort im Browser nutzbar** → **Run workflow**
5. Nach etwa einer Minute steht die Adresse in der Zusammenfassung des Laufs, etwa `https://deinname.github.io/orion/`

Diese Adresse am Handy öffnen. Dort funktionieren Mikrofon, Kamera und die neuronale Stimme. Über das Chrome-Menü **Zum Startbildschirm hinzufügen** liegt ORION danach als App auf dem Handy.

## Weg 1 — ohne GitHub

[app.netlify.com/drop](https://app.netlify.com/drop) öffnen, `index.html` hineinziehen, fertige HTTPS-Adresse benutzen.

---

## Der Systemcheck

Oben rechts das Stethoskop-Symbol, dann **Alles prüfen**. Sieben Punkte, jeder sagt dir im Klartext was fehlt:

| Punkt | Was er prüft |
|---|---|
| Sichere Verbindung | HTTPS vorhanden? |
| Mikrofon | Zugriff erlaubt, kommt Ton an? |
| Spracheingabe | Welche Erkennung aktiv ist |
| Kamera | Antwortet eine Kamera? |
| Bildschirm teilen | Kann dieser Browser es? |
| Verbindung zum Modell | Echte Anfrage an Gemini, zeigt den exakten Fehler |
| Neuronale Stimme | Spricht einen Satz — hörst du ihn, stimmt alles |

Solange irgendwo ein rotes ✕ steht, blinkt das Symbol.

---

## Die Stimme

**Standard ist neuronal über Gemini.** Das sind echte Sprachmodell-Stimmen, kein Übersetzer-Blech. Acht zur Auswahl, Kore ist voreingestellt.

Wenn sie trotzdem blechern klingt, ist die neuronale Stimme fehlgeschlagen und die Gerätestimme übernimmt. ORION sagt dir das jetzt sichtbar in einer roten Meldung mit dem genauen Grund. Häufigste Ursachen:

- Kein Schlüssel eingetragen
- Fehler 404 → das TTS-Modell ist für deinen Schlüssel nicht freigeschaltet
- Fehler 429 → Kontingent für den Moment leer

Im Zahnrad gibt es den Knopf **Stimme jetzt testen** — der spielt sofort einen Satz ab, ohne dass du speichern musst.

## Reden

Drei Wege, ORION nimmt automatisch den besten:

1. **Browser-Erkennung** — Chrome und Edge, am schnellsten
2. **Android-Erkennung** — in der APK über das Sprach-Plugin
3. **Aufnahme über Gemini** — überall sonst. ORION nimmt auf, Gemini schreibt mit. Etwa eine Sekunde langsamer, funktioniert dafür in jedem Browser inklusive Safari.

Dazu gibt es unten den Knopf **Gedrückt halten und sprechen**. Der geht immer, auch wenn die Dauererkennung zickt.

Im Gespräch wartet ORION deine Sprechpause ab (einstellbar) und antwortet erst dann. Er beginnt zu sprechen, sobald der erste Satz fertig ist. **Auf den Ring tippen unterbricht ihn.**

---

## API-Schlüssel

Kostenlos bei [aistudio.google.com/apikey](https://aistudio.google.com/apikey).

Neue Schlüssel beginnen bei manchen Konten mit `AQ.` statt `AIza` — Google stellt das Format gerade um. Beide funktionieren am Gemini-Endpunkt, den ORION nutzt.

**Modellname:** Feld leer lassen. ORION fragt beim ersten Gebrauch ab, welche Modelle dein Schlüssel darf, und wählt das neueste Flash-Modell. Läuft eines aus, sucht er beim nächsten Fehler automatisch ein neues. Im Zahnrad gibt es zusätzlich **Verfügbare Modelle laden**, wenn du selbst wählen willst.

**Wirklich ohne Limit:** Ollama auf dem PC, Modell `llama3.2-vision`, in ORION auf „OpenAI-kompatibel" umstellen und `http://DEINE-PC-IP:11434/v1` eintragen. Vorher am PC `OLLAMA_HOST=0.0.0.0` und `OLLAMA_ORIGINS=*` setzen.

---

## APK bauen

1. Repo bei GitHub anlegen, alle Dateien hochladen (auch den Ordner `.github`)
2. Reiter **Actions** → **1 – APK zum Testen** → **Run workflow**
3. Nach etwa 5 Minuten unter **Artifacts** die APK herunterladen
4. Aufs Handy schieben, installieren, Mikrofon und Kamera erlauben

## In den Play Store

Das ist ein eigener Weg — eine Debug-APK nimmt Google nicht an. Reihenfolge:

**Schritt 1 — Schlüssel erzeugen (einmalig)**
Actions → **3 – Schlüssel erzeugen** → Passwort vergeben → starten.
Lade das Artefakt herunter und **bewahre `orion.jks` sicher auf**. Verlierst du es, kannst du deine App nie wieder aktualisieren. Es gibt keinen Ersatz.

**Schritt 2 — Secrets eintragen**
Repo → Settings → Secrets and variables → Actions → New repository secret:

| Name | Inhalt |
|---|---|
| `KEYSTORE_BASE64` | Inhalt der Datei `orion.jks.base64` |
| `KEYSTORE_PASSWORD` | dein Passwort |
| `KEY_ALIAS` | `orion` |
| `KEY_PASSWORD` | dasselbe Passwort |

Danach das Artefakt bei GitHub löschen.

**Schritt 3 — Paket bauen**
Actions → **2 – Play-Store-Paket (AAB)** → Version eintragen → starten → `app-release.aab` herunterladen.

**Schritt 4 — Was Google zusätzlich verlangt**

- Entwicklerkonto: einmalig 25 US-Dollar
- Neue Konten müssen die App vor Veröffentlichung **14 Tage mit mindestens 12 Testern** laufen lassen
- **Datenschutzerklärung** als öffentliche Internetseite — Pflicht, weil ORION Mikrofon und Kamera nutzt
- **Formular zur Datensicherheit**: dort angeben, dass Audio und Bilder zur Verarbeitung an Google Gemini gehen und nichts gespeichert wird
- Symbol 512×512, Vorschaubild 1024×500, mindestens zwei Bildschirmfotos
- Altersfreigabe-Fragebogen

Das dauert realistisch ein paar Tage, nicht wegen des Bauens, sondern wegen der Prüfung.

---

## Was wo funktioniert

| Funktion | APK | Chrome PC | Chrome Handy | Safari |
|---|---|---|---|---|
| Sprechen und Zuhören | ja | ja | ja | über Aufnahme |
| Neuronale Stimme | ja | ja | ja | ja |
| Kamera | ja | ja | ja | ja |
| Bildschirm mitlesen | nein* | ja | nein | nein |
| Nachrichten mit Links | ja | ja | ja | ja |
| Gedächtnis | ja | ja | ja | ja |

\* Android erlaubt keiner Webansicht das Mitlesen des Bildschirms. Am PC geht es, am Handy Kamera auf den Monitor halten.

---

## Wenn etwas klemmt

- **Alles tot, nichts geht** → Systemcheck öffnen. Steht bei „Sichere Verbindung" ein ✕, öffnest du die Datei aus dem Ordner statt über eine Adresse. Siehe Weg 0.
- **„Modell nicht gefunden"** → einmal „Verfügbare Modelle laden" im Zahnrad drücken, oder das Modellfeld leeren und speichern.
- **Kein Ton, obwohl alles grün** → einmal irgendwo auf die Seite tippen. Browser blockieren Ton bis zur ersten Berührung.
- **Einstellungen verkorkst** → im Zahnrad ganz unten **Alles zurücksetzen**.
- **Build rot bei GitHub** → meist fehlt der Ordner `.github`. Beim Hochladen werden versteckte Ordner übersprungen. Dann über **Add file → Create new file** den Pfad `.github/workflows/build-apk.yml` von Hand anlegen.
- **ORION hört in der APK nichts** → Android-Einstellungen → Apps → ORION → Berechtigungen → Mikrofon. Auf manchen Geräten liefert erst die Google-App die Spracherkennung.
