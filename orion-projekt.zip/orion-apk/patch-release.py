#!/usr/bin/env python3
"""Traegt Signatur-Einstellungen und Versionsnummer in build.gradle ein."""
import os, re, pathlib, sys

p = pathlib.Path("android/app/build.gradle")
if not p.exists():
    sys.exit("build.gradle nicht gefunden")
g = p.read_text(encoding="utf-8")

# 1. signingConfig ZUERST in den release-Block innerhalb von buildTypes setzen
if "signingConfig signingConfigs.release" not in g:
    i = g.find("buildTypes")
    if i == -1:
        sys.exit("buildTypes nicht gefunden")
    m = re.compile(r'release\s*\{').search(g, i)
    if not m:
        sys.exit("release-Block nicht gefunden")
    g = g[:m.end()] + "\n            signingConfig signingConfigs.release" + g[m.end():]

# 2. Danach den signingConfigs-Block davor einhaengen
if "signingConfigs {" not in g:
    block = '''
    signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_PATH"))
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
'''
    g = re.sub(r'\n(\s*)buildTypes\s*\{', block + r'\n\1buildTypes {', g, count=1)

# 3. Version setzen
code = os.environ.get("VERSION_CODE", "1")
name = os.environ.get("VERSION_NAME", "1.0.0")
g = re.sub(r'versionCode\s+\d+', f'versionCode {code}', g)
g = re.sub(r'versionName\s+"[^"]*"', f'versionName "{name}"', g)

p.write_text(g, encoding="utf-8")
print(f"Signatur eingetragen, Version {name} ({code})")
