#!/usr/bin/env python3
"""Traegt Kamera-, Mikrofon- und Netz-Berechtigungen in die AndroidManifest.xml ein."""
import re, pathlib, sys

p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
if not p.exists():
    sys.exit("AndroidManifest.xml nicht gefunden")

xml = p.read_text(encoding="utf-8")

perms = [
    "android.permission.INTERNET",
    "android.permission.RECORD_AUDIO",
    "android.permission.CAMERA",
    "android.permission.MODIFY_AUDIO_SETTINGS",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.VIBRATE",
]
block = "\n".join(f'    <uses-permission android:name="{x}" />' for x in perms)
block += (
    '\n    <uses-feature android:name="android.hardware.camera" android:required="false" />'
    '\n    <uses-feature android:name="android.hardware.microphone" android:required="false" />'
    '\n    <queries><intent><action android:name="android.speech.RecognitionService" />'
    '</intent></queries>\n'
)

# alte Eintraege entfernen, damit nichts doppelt drinsteht
xml = re.sub(r'\s*<uses-permission[^>]*/>', '', xml)
xml = re.sub(r'\s*<uses-feature[^>]*/>', '', xml)
xml = xml.replace("</manifest>", block + "</manifest>")

# Klartext-Verbindungen erlauben (fuer Ollama im Heimnetz)
if "usesCleartextTraffic" not in xml:
    xml = xml.replace("<application", '<application android:usesCleartextTraffic="true"', 1)

p.write_text(xml, encoding="utf-8")
print("Berechtigungen eingetragen.")
